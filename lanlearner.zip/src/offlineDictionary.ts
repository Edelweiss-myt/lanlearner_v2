// offlineDictionary.ts
export interface OfflineWord {
  english: string;
  chinese: string;
  partOfSpeech?: string; // e.g., "n.", "v.", "adj."
  example?: string; // Optional: example sentence
}

// 用户注意：这是一个示例离线词库。
// 请在此处填充您完整的3000个中英词汇。
// 词条越多，文件越大，可能会影响应用初始加载速度。
// 考虑更优化的数据加载方式，例如从JSON文件加载。
export const offlineWords: OfflineWord[] = [
  { english: "hello", chinese: "你好", partOfSpeech: "int." },
  { english: "world", chinese: "世界", partOfSpeech: "n." },
  { english: "apple", chinese: "苹果", partOfSpeech: "n.", example: "An apple a day keeps the doctor away." },
  { english: "love", chinese: "爱", partOfSpeech: "n./v." },
  { english: "learn", chinese: "学习", partOfSpeech: "v." },
  { english: "happy", chinese: "快乐的", partOfSpeech: "adj." },
  { english: "book", chinese: "书", partOfSpeech: "n." },
  { english: "read", chinese: "阅读", partOfSpeech: "v." },
  { english: "water", chinese: "水", partOfSpeech: "n." },
  { english: "computer", chinese: "电脑", partOfSpeech: "n." },
  { english: "search", chinese: "搜索；搜寻", partOfSpeech: "v./n." },
  { english: "dictionary", chinese: "词典；字典", partOfSpeech: "n." },
  { english: "offline", chinese: "离线的；脱机的", partOfSpeech: "adj./adv." },
  // ... 请在此处添加更多词汇
];

export const findOfflineWord = (term: string): OfflineWord | undefined => {
  if (!term) return undefined;
  const searchTerm = term.trim().toLowerCase();
  return offlineWords.find(word => word.english.toLowerCase() === searchTerm);
};