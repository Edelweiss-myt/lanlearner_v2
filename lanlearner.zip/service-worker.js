
const CACHE_NAME = 'lanlearner-cache-v1.2'; // Increment version to force update
const urlsToCache = [
  '/',
  '/index.html',
  '/index.tsx', // Assuming this is served as JS or your environment handles it
  '/manifest.json',
  // Add paths to your icons here. Ensure these files exist in an 'icons' directory.
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/apple-touch-icon.png', 
  // Note: CDN assets (Tailwind, esm.sh modules) are typically cached by the browser 
  // or have their own caching headers. Caching them directly in SW can be complex.
  // We are caching the app shell and local assets.
];

self.addEventListener('install', event => {
  console.log('[ServiceWorker] Install');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('[ServiceWorker] Caching app shell');
        // Add all URLs, but don't fail install if some minor ones (like icons not yet created) fail
        const promises = urlsToCache.map(url => {
          return cache.add(url).catch(err => {
            console.warn(`[ServiceWorker] Failed to cache ${url}: ${err}`);
          });
        });
        return Promise.all(promises);
      })
      .then(() => self.skipWaiting()) // Activate new SW immediately
  );
});

self.addEventListener('activate', event => {
  console.log('[ServiceWorker] Activate');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('[ServiceWorker] Removing old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim()) // Take control of open clients
  );
});

self.addEventListener('fetch', event => {
  // We only handle GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  // For navigation requests, try network first, then cache (Network-first strategy for HTML)
  // This ensures users get the latest HTML if online, but can fall back to cached if offline.
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          // If we get a valid response, cache it and return it
          if (response && response.status === 200 && response.type === 'basic') {
            const responseToCache = response.clone();
            caches.open(CACHE_NAME).then(cache => {
              cache.put(event.request, responseToCache);
            });
          }
          return response;
        })
        .catch(() => {
          // If network fails, try to serve from cache
          return caches.match(event.request)
            .then(cachedResponse => {
              return cachedResponse || caches.match('/index.html'); // Fallback to home page
            });
        })
    );
    return;
  }

  // For other assets (JS, CSS, images), use a Cache-first strategy.
  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        if (cachedResponse) {
          // console.log('[ServiceWorker] Fetching from cache:', event.request.url);
          return cachedResponse;
        }
        // console.log('[ServiceWorker] Fetching from network:', event.request.url);
        return fetch(event.request).then(
          response => {
            // If we get a valid response, cache it and return it
            // Only cache basic responses (same origin) to avoid caching opaque CDN responses by default
            if (response && response.status === 200 && response.type === 'basic' && urlsToCache.includes(new URL(event.request.url).pathname)) {
              const responseToCache = response.clone();
              caches.open(CACHE_NAME)
                .then(cache => {
                  cache.put(event.request, responseToCache);
                });
            }
            return response;
          }
        );
      })
      .catch(error => {
        console.error('[ServiceWorker] Fetch error:', error);
        // You could return a fallback offline page or image here if appropriate.
        // For simplicity, we're not adding one now.
      })
  );
});
